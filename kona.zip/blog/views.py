from django.shortcuts import render, get_object_or_404
from .models import Post, Category
import markdown

def blog_list(request):
    posts = Post.objects.all()
    categories = Category.objects.all()
    context = {
        'posts': posts,
        'categories': categories
    }
    return render(request, 'blog/blog_list.html', context)

def blog_detail(request, slug):
    post = get_object_or_404(Post, slug=slug)
    categories = Category.objects.all()
    post.content = markdown.markdown(post.content)
    context = {
        'post': post,
        'categories':categories
    }
    return render(request, 'blog/blog_detail.html', context)


def category_detail(request, slug):
    category = get_object_or_404(Category, slug=slug)
    posts = Post.objects.filter(category=category)
    context = {
    'category': category,
    'posts': posts
    }
    return render(request, 'blog/category_detail.html', context)