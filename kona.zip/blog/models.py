from django.db import models
from django.utils.text import slugify
from ckeditor.fields import RichTextField


class Category(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True, blank=True, null=True)

    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
        super(Category, self).save(*args, **kwargs)

    def __str__(self):
        return self.name


class Post(models.Model):
    title = models.CharField(max_length=1000)  # Allow long titles
    slug = models.SlugField(unique=True, blank=True, null=True, max_length=255)  # Increased slug length
    content = RichTextField()
    image = models.ImageField(upload_to='blog/', null=True, blank=True)
    category = models.ForeignKey('Category', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            # Create a slug and ensure it is unique
            base_slug = slugify(self.title)[:255]
            slug = base_slug
            counter = 1
            while Post.objects.filter(slug=slug).exists():
                # Append a counter to the slug if it's not unique
                slug = f"{base_slug[:250]}-{counter}"  # Adjust to fit max_length
                counter += 1
            self.slug = slug
        super(Post, self).save(*args, **kwargs)

    def __str__(self):
        return self.title
