from django import forms
from .models import TicketDetails, TicketHolder

from django import forms
from .models import TicketHolder, TicketDetails

class TicketPurchaseForm(forms.Form):
    quantity = forms.IntegerField(min_value=1, max_value=10)
    ticket_type = forms.ModelChoiceField(queryset=TicketDetails.objects.none())

    def __init__(self, *args, **kwargs):
        event = kwargs.pop('event', None)
        super().__init__(*args, **kwargs)
        if event:
            self.fields['ticket_type'].queryset = TicketDetails.objects.filter(event=event)

class TicketHolderForm(forms.ModelForm):
    class Meta:
        model = TicketHolder
        fields = ['name', 'surname','identity_number']

TicketHolderFormSet = forms.modelformset_factory(
    TicketHolder,
    form=TicketHolderForm,
    extra=0,
    min_num=1,
    validate_min=True
)
