from django.contrib import admin
from .models import TicketDetails, TicketAvailability,Ticket,TicketHolder,TicketSales

@admin.register(TicketAvailability)
class TicketAvailabilityAdmin(admin.ModelAdmin):
    list_display = ('ticket_details', 'quantity', 'sold', 'tickets_remaining', 'available')
    readonly_fields = ('tickets_remaining',)

admin.site.register(TicketDetails)
admin.site.register(Ticket)
admin.site.register(TicketHolder)
admin.site.register(TicketSales)
