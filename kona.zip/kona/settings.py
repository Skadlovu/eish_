from pathlib import Path
import os
from datetime import timedelta
from google.oauth2 import service_account
from decouple import config



CORS_ALLOWED_ORIGINS = [
    "https://storage.googleapis.com"
]


# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/5.1/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY =config('SECRET_KEY')

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False
ALLOWED_HOSTS = ['www.linkupkona.co.za', 'linkupkona.co.za', '129.151.184.167']

LOGIN_URL='customer:login'
LOGIN_REDIRECT_URL='/'



CRISPY_ALLOWED_TEMPLATE_PACKS = "bootstrap5"
CRISPY_TEMPLATE_PACK = "bootstrap5"



# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'event',
    'organiser',
    'ticket',
    'customer',
    'cart',
    #'debtor',
    'payfast',
    'storages',
    'crispy_forms',
    'crispy_bootstrap5',
    'formtools',
    'taggit',
    'rest_framework',
    'rest_framework.authtoken',
    'support',
    'django_crontab',
    'blog',
    'markdownx',
    'ckeditor',
    'decouple'


]


MARKDOWNX_MARKDOWN_EXTENSIONS = [
    'markdown.extensions.fenced_code',
    'markdown.extensions.codehilite',
    'markdown.extensions.tables',
]
CRONJOBS = [
    # Run the task every day at 9:00 AM
    ('0 9 * * *', 'organiser.cron.generate_daily_sales_report')
]

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.SessionAuthentication',  # For session-based authentication
        'rest_framework.authentication.BasicAuthentication',  # Optional
        'rest_framework_simplejwt.authentication.JWTAuthentication',  # For JWT authentication (if using JWT)
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ]
}

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=60),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=1),
    'ROTATE_REFRESH_TOKENS': False,
    'BLACKLIST_AFTER_ROTATION': True,
    'UPDATE_LAST_LOGIN': False,
}


MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'middleware.middleware.OrganiserAccessMiddleware',
    'middleware.middleware.CustomerAccessMiddleware'


]

ROOT_URLCONF = 'kona.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',


		'context_processors.context_processors.categories',
                'context_processors.context_processors.cart_item_count'
            ],
        },
    },
]

WSGI_APPLICATION = 'kona.wsgi.application'

# Database
# https://docs.djangoproject.com/en/5.1/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',  # PostgreSQL database engine
        'NAME': 'newdatabase001',                     # Replace with your new database name
        'USER': 'newuser',                         # Replace with your new database user
        'PASSWORD': 'newpassword',                 # Replace with the new user's password
        'HOST': 'localhost',                       # Use 'localhost' if the database is on the same server
        'PORT': '5432',                            # Default PostgreSQL port
    }
}



# Password validation
# https://docs.djangoproject.com/en/5.1/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
# https://docs.djangoproject.com/en/5.1/topics/i18n/

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Africa/Johannesburg'
USE_I18N = True
USE_TZ = True

"""
# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/5.1/howto/static-files/

STATIC_URL = '/static/'

# Directory where collectstatic will collect static files for deployment
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')

# Additional locations of static files
STATICFILES_DIRS = [os.path.join(BASE_DIR, 'static')]  # Correct path for static files directory

MEDIA_URL = '/media/'

MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
"""

# Default primary key field type
# https://docs.djangoproject.com/en/5.1/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'


LOGIN_REDIRECT_URL='/'

LOGOUT_REDIRECT_URL='/'

BASE_URL='https://www.linkupkona.co.za/'

PAYFAST_MERCHANT_ID=config('merchant_id')

PAYFAST_MERCHANT_KEY=config('merchant_key')

PAYFAST_PASSPHRASE='xxxworld.com'

PAYFAST_URL= 'https://sandbox.payfast.co.za​/eng/process'


EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = config('EMAIL_HOST_USER')
EMAIL_HOST_PASSWORD =config('EMAIL_HOST_PASSWORD')

# Use this email address as the default sender for all emails
DEFAULT_FROM_EMAIL = config('EMAIL_HOST_USER')



# G storage credentials
GS_CREDENTIALS = service_account.Credentials.from_service_account_file(
    os.path.join(BASE_DIR, 'orbital-anchor-414318-b3af899ba150.json')
)

# Google Cloud Storage bucket name
GS_BUCKET_NAME = 'linkup_bucket'



MEDIA_FOLDER='/media/'

STATIC_FOLDER='/static/'

# Google Cloud Storage base URL for media files
MEDIA_URL= f'https://storage.googleapis.com/{GS_BUCKET_NAME}/media/'

#Mediafiles storage backend
DEFAULT_FILE_STORAGE = 'kona.gscUtils.MediaStorage'



# Google Cloud Storage base URL for static files
STATIC_URL=f'https://storage.googleapis.com/{GS_BUCKET_NAME}/static/'

# Staticfiles storage backend
STATICFILES_STORAGE = 'kona.gscUtils.StaticStorage'




GS_OBJECT_PARAMETERS = {
    'CacheControl': 'max-age=86400',
}

GS_DEFAULT_ACL = 'publicRead'
GS_FILE_OVERWRITE = False





