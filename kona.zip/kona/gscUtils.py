from google.cloud import storage
from storages.backends.gcloud import GoogleCloudStorage
from django.conf import settings
from django.core.files.storage import default_storage
import os

class StaticStorage(GoogleCloudStorage):
    location = 'static'
    file_overwrite = True
    
    def __init__(self, *args, **kwargs):
        kwargs['credentials'] = settings.GS_CREDENTIALS
        kwargs['bucket_name'] = settings.GS_BUCKET_NAME
        super().__init__(*args, **kwargs)


class MediaStorage(GoogleCloudStorage):
    def __init__(self, **kwargs):
        kwargs.update({
            "credentials": settings.GS_CREDENTIALS,
            "bucket_name": settings.GS_BUCKET_NAME,
            "file_overwrite": False,
        })
        super().__init__(**kwargs)

    def get_valid_name(self, name):
        """
        Returns a filename that's transformed to work with GCS
        """
        name = super().get_valid_name(name)
        if name.startswith('/'):
            name = name[1:]
        return name
def upload_file_to_gcs(file_obj, destination_blob_name):
    """
    Helper function to upload a file to GCS
    """
    try:
        storage_client = storage.Client(credentials=settings.GS_CREDENTIALS)
        bucket = storage_client.bucket(settings.GS_BUCKET_NAME)
        blob = bucket.blob(destination_blob_name)
        
        # Upload the file
        blob.upload_from_file(file_obj)
        
        # Make the blob publicly readable
        blob.make_public()
        
        return blob.public_url
    except Exception as e:
        print(f"Error uploading file: {str(e)}")
        return None
